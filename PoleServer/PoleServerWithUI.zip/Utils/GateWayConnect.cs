﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modbus.Device;
using System.IO.Ports;
using System.Net.Sockets;
using PoleServerWithUI.Model;
using System.Collections.ObjectModel;
using System.Net;

namespace PoleServerWithUI.Utils
{
    class GateWayConnect
    {
        List<TcpClient> tcpClients;
        TcpListener server;

        // Gateway 연결
        public async void GatewayConnect(ObservableCollection<DeviceModel> deviceModels)
        {
            tcpClients = new List<TcpClient>();
            const int bindPort = 502;
            server = null;
            try
            {
                server = new TcpListener(IPAddress.Any, bindPort);

                server.Start();


               LogMessage.Instance.Log.Add("메아리 서버 시작...");

                await Task.Run(() =>
                {
                    while (true)
                    {
                        TcpClient client = server.AcceptTcpClient();
                        DispatcherService.Invoke((System.Action)(() =>
                        {
                            LogMessage.Instance.Log.Add(String.Format("클라이언트 접속: {0} ", ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString()));
                        }));
                            tcpClients.Add(client);

                        DeviceModel data = null;
                        foreach(var device in deviceModels)
                        {
                            if (device.Ip .Equals(((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString()))
                            {
                                device.Connected = true;
                                data = device;
                                DispatcherService.Invoke((System.Action)(() =>
                                {
                                    LogMessage.Instance.Log.Add(String.Format("클라이언트 IP : {0}, Connection : {1}", data.Ip, data.Connected));
                                }));
                            }
                        }

                        Task.Delay(100);
                    }
                });
            }
            catch (SocketException e)
            {
                Console.WriteLine(e);
            }

        }

        public async void DataPolling(ObservableCollection<DeviceModel> deviceModels)
        {
            await Task.Run(async() =>
            {
                while (true)
                {
                    try
                    {
                        foreach (var client in tcpClients)
                        {
                            string sendData = string.Empty;
                            DeviceModel dataModel;
                            foreach (var device in deviceModels)
                            {
                                if (device.Ip.Equals(((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString()))
                                {
                                    dataModel = device;
                                    sendData = device.TxData;
                                }
                                else
                                {
                                    continue;
                                }
                            }

                            if (string.IsNullOrEmpty(sendData))
                                continue;

                            NetworkStream stream = client.GetStream();

                            byte[] msg = Encoding.Default.GetBytes(sendData);
                            stream.Write(msg, 0, msg.Length);
                            DispatcherService.Invoke((System.Action)(() =>
                            {
                                LogMessage.Instance.Log.Add(String.Format("송신: {0}", sendData));
                            }));

                            stream.ReadTimeout = 10000;
                            byte[] datas = new byte[256];

                            string responseData = "";
                            int bytes = stream.Read(datas, 0, datas.Length);
                            responseData = Encoding.Default.GetString(datas, 0, bytes);
                            DispatcherService.Invoke((System.Action)(() =>
                            {
                                LogMessage.Instance.Log.Add(String.Format("수신 : {0}", responseData));
                            }));
                        }

                        // 데이터 포맷에 맞춰서 저장 후 반환

                        PoleLogModel poleLogModel = new PoleLogModel();
                        //

                    }
                    catch (Exception e)
                    {
                        DispatcherService.Invoke((System.Action)(() =>
                        {
                            LogMessage.Instance.Log.Add("Data Read Error : " + e);
                        }));
                    }

                    await Task.Delay(10000);
                }
            });
        }

 
        // Gateway 를 통한 데이터 로드
        public PoleLogModel DataLoad(string sendData, DeviceModel device)
        {
            try
            {
                TcpClient client = null;
                foreach(var tcp in tcpClients)
                {
                    if (((IPEndPoint)tcp.Client.RemoteEndPoint).Address.ToString() == device.Ip)
                        client = tcp;
                }

                if (client == null)
                    return null;

                NetworkStream stream = client.GetStream();

                byte[] msg = Encoding.Default.GetBytes(sendData);
                stream.Write(msg, 0, msg.Length);
                Console.WriteLine(String.Format("송신: {0}", sendData));

                stream.ReadTimeout = 1000;

                byte[] datas = new byte[256];
                string responseData = "";
                int bytes = stream.Read(datas, 0, datas.Length);
                responseData = Encoding.Default.GetString(datas, 0, bytes);
                Console.WriteLine("수신 : {0}", responseData);

                stream.Close();
                // 데이터 포맷에 맞춰서 저장 후 반환

                PoleLogModel poleLogModel = new PoleLogModel();
                //

                return poleLogModel;
            }
            catch(Exception e)
            {
                Console.WriteLine("Data Read Error : " + e);
                return null;
            }
        }

        public bool GatewayDisConnect()
        {
            foreach(var tcp in tcpClients)
            {
                tcp.Close();
            }
            return true;
        }
    }
}
